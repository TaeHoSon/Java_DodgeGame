package first;

abstract public class DirectionStrategy {

	Client client;
	abstract public void move(Ball ball);
	
	
	
	
	
}
