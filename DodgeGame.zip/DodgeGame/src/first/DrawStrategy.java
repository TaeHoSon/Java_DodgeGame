package first;

abstract public class DrawStrategy {
	abstract public void draw(Ball ball);
}
